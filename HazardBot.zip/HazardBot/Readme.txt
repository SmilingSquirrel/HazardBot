HazardBot!

Made by SmilingSquirrel
For BGMC33 (9/24/20 - 10/1/20)

You are a robot.
Your human masters have sent you to enter an old facility in seach of "The End".
There are many traps in the stone structure.
The humans have brought quite a lot of robots with them, hopefully one will make it through!

Controls:

Gamepad: Move-Right Joystick, Jump-"A" Button, Back to menu-"Back" Button
Keyboard: Move-"A" + "D" Key, Jump-"Space" Key, Back to menu-"Esc"
Quit: F4
You can triple jump.



Other notes:
The "robot counter" resets for each level. It does not keep a talley of robots for
   your whole playthrough.

I have noticed frame-rate dips on Level 3 when the player jumps. (Rasterizer spikes to 20%)
    If problem carries over to other levels, please let me know so I can publish an older version.

Feel free to post robot counts or playthrough times for levels on the BA thread, if
   you like a little competition.

Due to the difficulty of the game, all levels are accessable from the main menu.

"Quit blender" is bound to "F4" due to a mixup between the gamepad "Start" button, and a keyboard sensor set to "Esc".



Credits:
All models, animations, textures and sounds were made by SmilingSquirrel.